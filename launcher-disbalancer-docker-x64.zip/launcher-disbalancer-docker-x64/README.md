# launcher-disbalancer

## How to build

`docker build -t launcher-disbalancer .`

## How to run

`docker run --restart unless-stopped launcher-disbalancer`
